import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const Login = () => {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const { email, password } = formData;

  const onChange = (e) => setFormData({ ...formData, [e.target.name]: e.target.value });

  const onSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post('http://localhost:5001/api/auth/login', formData, {
        withCredentials: false,
      });
      console.log(res.data);
      // Kullanıcı bilgilerini ve token'ı localStorage'a kaydet
      localStorage.setItem('token', res.data.token);
      localStorage.setItem('user', JSON.stringify(res.data.user));
      // Başarılı girişten sonra profile yönlendir
      navigate('/profile');
    } catch (err) {
      console.error(err);
      setError(err.response?.data?.msg || 'Sunucu hatası');
    }
  };

  return (
    <form onSubmit={onSubmit}>
      <div>
        <label>Email:</label>
        <input type="email" name="email" value={email} onChange={onChange} required />
      </div>
      <div>
        <label>Şifre:</label>
        <input type="password" name="password" value={password} onChange={onChange} required />
      </div>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <button type="submit">Giriş Yap</button>
    </form>
  );
};

export default Login;
