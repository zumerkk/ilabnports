import React, { useEffect, useState } from 'react';
import axios from 'axios';

const AdList = () => {
  const [ads, setAds] = useState([]);

  useEffect(() => {
    // İlanları almak için API çağrısı yap
    const fetchAds = async () => {
      try {
        const res = await axios.get('http://localhost:5001/api/ads');
        setAds(res.data);
      } catch (err) {
        console.error(err);
      }
    };

    fetchAds();
  }, []);

  return (
    <div>
      {ads.map(ad => (
        <div key={ad._id} className="ad">
          <h3>{ad.title}</h3>
          <p>{ad.description}</p>
          <p>Fiyat: {ad.price} TL</p>
        </div>
      ))}
    </div>
  );
};

export default AdList;
