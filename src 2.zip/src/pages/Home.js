import React from 'react';
import AdList from '../components/AdList';
import './Home.css';

const Home = () => {
  return (
    <div className="home">
      <h1>İlan Port'a Hoşgeldiniz</h1>
      <div className="showroom">
        <h2>Son Eklenen İlanlar</h2>
        <AdList />
      </div>
    </div>
  );
};

export default Home;
