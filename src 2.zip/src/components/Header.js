import React from 'react';
import { Link } from 'react-router-dom';
import './Header.css';

const Header = () => {
  return (
    <header className="header">
      <div className="logo">
        <Link to="/">İlan Port</Link>
      </div>
      <div className="search">
        <input type="text" placeholder="Ara..." />
      </div>
      <div className="auth-links">
        <Link to="/register">Kayıt Ol</Link>
        <Link to="/login">Giriş Yap</Link>
      </div>
    </header>
  );
};

export default Header;