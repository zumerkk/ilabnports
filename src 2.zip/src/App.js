import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Header from './components/Header';
import Home from './pages/Home';
import Showroom from './pages/Showroom';
import Register from './components/Register';
import Login from './components/Login';
import Profile from './components/Profile';
import AddAd from './components/AddAd';

const App = () => {
  return (
    <Router>
      <Header />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/showroom" element={<Showroom />} />
        <Route path="/register" element={<Register />} />
        <Route path="/login" element={<Login />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/add-ad" element={<AddAd />} />
      </Routes>
    </Router>
  );
};

export default App;
