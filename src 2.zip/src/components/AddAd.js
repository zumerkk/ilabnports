import React, { useState } from 'react';
import axios from 'axios';
import './AddAd.css';

const AddAd = () => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    price: '',
    category: '',
    images: [],
  });
  const [previewImages, setPreviewImages] = useState([]);
  const [error, setError] = useState(null);

  const { title, description, price, category } = formData;

  const onChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const onFileChange = (e) => {
    const files = Array.from(e.target.files);
    setFormData({ ...formData, images: files });

    // Resim önizleme için
    const preview = files.map((file) => URL.createObjectURL(file));
    setPreviewImages(preview);
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    try {
      const userId = JSON.parse(localStorage.getItem('user'))._id;
      const formDataToSend = new FormData();
      formDataToSend.append('title', title);
      formDataToSend.append('description', description);
      formDataToSend.append('price', price);
      formDataToSend.append('category', category);
      formDataToSend.append('userId', userId);
      formData.images.forEach((image) => {
        formDataToSend.append('images', image);
      });

      const res = await axios.post('http://localhost:5001/api/ads', formDataToSend, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      console.log(res.data);
    } catch (err) {
      console.error(err);
      setError(err.response?.data?.msg || 'Sunucu hatası');
    }
  };

  return (
    <div className="add-ad-container">
      <h2>Yeni İlan Ekle</h2>
      <form onSubmit={onSubmit} className="add-ad-form">
        <div className="form-group">
          <label htmlFor="title">Başlık:</label>
          <input type="text" name="title" value={title} onChange={onChange} required />
        </div>
        <div className="form-group">
          <label htmlFor="description">Açıklama:</label>
          <textarea name="description" value={description} onChange={onChange} required></textarea>
        </div>
        <div className="form-group">
          <label htmlFor="price">Fiyat:</label>
          <input type="number" name="price" value={price} onChange={onChange} required />
        </div>
        <div className="form-group">
          <label htmlFor="category">Kategori:</label>
          <select name="category" value={category} onChange={onChange} required>
            <option value="">Kategori Seçin</option>
            <option value="elektronik">Elektronik</option>
            <option value="mobilya">Mobilya</option>
            <option value="giyim">Giyim</option>
            <option value="araba">Araba</option>
            <option value="emlak">Emlak</option>
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="images">Resimler:</label>
          <input type="file" name="images" multiple onChange={onFileChange} />
          <div className="image-previews">
            {previewImages.map((src, index) => (
              <img key={index} src={src} alt={`Preview ${index + 1}`} />
            ))}
          </div>
        </div>
        {error && <p className="error-msg">{error}</p>}
        <button type="submit" className="submit-btn">İlan Ekle</button>
      </form>
    </div>
  );
};

export default AddAd;
