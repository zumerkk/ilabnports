import React, { useEffect, useState } from 'react';
import axios from 'axios';

const Profile = () => {
  const [ads, setAds] = useState([]);
  const user = JSON.parse(localStorage.getItem('user'));

  useEffect(() => {
    const fetchAds = async () => {
      try {
        const res = await axios.get(`http://localhost:5001/api/ads`);
        const userAds = res.data.filter(ad => ad.userId._id === user._id);
        setAds(userAds);
      } catch (err) {
        console.error(err);
      }
    };

    fetchAds();
  }, [user._id]);

  if (!user) {
    return <p>Giriş yapmanız gerekmektedir.</p>;
  }

  return (
    <div>
      <h1>Profil Sayfası</h1>
      <p>İsim: {user.name}</p>
      <p>Email: {user.email}</p>
      <p>Telefon: {user.phone}</p>
      <p>Üyelik Türü: {user.isCorporate ? 'Kurumsal' : 'Bireysel'}</p>
      <h2>İlanlarım</h2>
      {ads.map(ad => (
        <div key={ad._id} className="ad">
          <h3>{ad.title}</h3>
          <p>{ad.description}</p>
          <p>Fiyat: {ad.price} TL</p>
        </div>
      ))}
    </div>
  );
};

export default Profile;
