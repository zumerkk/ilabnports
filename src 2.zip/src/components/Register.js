import React, { useState } from 'react';
import axios from 'axios';

const Register = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    password: '',
    isCorporate: false,
  });
  const [error, setError] = useState(null);

  const { name, email, phone, password, isCorporate } = formData;

  const onChange = (e) => setFormData({ ...formData, [e.target.name]: e.target.value });

  const onSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post('http://localhost:5001/api/auth/register', formData, {
        withCredentials: false,
      });
      console.log(res.data);
    } catch (err) {
      console.error(err);
      setError(err.response?.data?.msg || 'Sunucu hatası');
    }
  };

  return (
    <form onSubmit={onSubmit}>
      <div>
        <label>İsim:</label>
        <input type="text" name="name" value={name} onChange={onChange} required />
      </div>
      <div>
        <label>Email:</label>
        <input type="email" name="email" value={email} onChange={onChange} required />
      </div>
      <div>
        <label>Telefon:</label>
        <input type="text" name="phone" value={phone} onChange={onChange} required />
      </div>
      <div>
        <label>Şifre:</label>
        <input type="password" name="password" value={password} onChange={onChange} required />
      </div>
      <div>
        <label>
          <input type="checkbox" name="isCorporate" checked={isCorporate} onChange={() => setFormData({ ...formData, isCorporate: !isCorporate })} />
          Kurumsal Üye
        </label>
      </div>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <button type="submit">Kayıt Ol</button>
    </form>
  );
};

export default Register;
