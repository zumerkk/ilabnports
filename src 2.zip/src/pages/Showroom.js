import React from 'react';

const Showroom = () => {
  return (
    <div>
      <h1>Son Eklenen İlanlar</h1>
      {/* Showroom içeriği buraya gelecek */}
    </div>
  );
};

export default Showroom;
